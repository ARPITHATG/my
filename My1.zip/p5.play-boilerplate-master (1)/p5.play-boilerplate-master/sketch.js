
const Engine = Matter.Engine;
const World = Matter.World;
const Bodies = Matter.Bodies;

var engine, world;
var object1;

function setup() {
  createCanvas(400,400);
  engine = Engine.create();
  world = engine.world;

  var options = {

    isStatic : true
  }

  object1 = Bodies.rectangle(200, 100, 50,50, options)
  World.add(world, object1)
  console.log(object1)
  console.log(object1.type)
  console.log(object1.position.x)
  console.log(object1.position.y)
}

function draw() {
  background("PINK");  
  rectMode(CENTER)
  rect(object1.position.x, object1.position.y, 50, 50)
  drawSprites();
}